document.getElementById('train-search-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Example train data
    const trains = [
        {
            trainNo: '12345',
            trainName: 'Express Train',
            departure: '10:00 AM',
            arrival: '02:00 PM',
            duration: '4h',
            class: 'Sleeper',
            availability: 'Available',
            fare: '$50'
        },
        // Add more train objects here
    ];

    const resultsTableBody = document.querySelector('#train-results-table tbody');
    resultsTableBody.innerHTML = ''; // Clear previous results

    trains.forEach(train => {
        const row = document.createElement('tr');
        
        Object.values(train).forEach(value => {
            const cell = document.createElement('td');
            cell.textContent = value;
            row.appendChild(cell);
        });

        const bookCell = document.createElement('td');
        const bookButton = document.createElement('button');
        bookButton.textContent = 'Book';
        bookButton.addEventListener('click', function() {
            alert('Booking for ' + train.trainName);
        });
        bookCell.appendChild(bookButton);
        row.appendChild(bookCell);

        resultsTableBody.appendChild(row);
    });
});
